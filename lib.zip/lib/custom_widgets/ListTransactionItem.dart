import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/transaction.dart';

class ListTransactionItem extends StatelessWidget {
  const ListTransactionItem({
    super.key,
    required this.tx,
    required this.deleteTx,
  });

  final Transaction tx;
  final Function deleteTx;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 10,
      margin: EdgeInsets.symmetric(vertical: 10, horizontal: 5),
      child: ListTile(
        leading: Container(
          height: 50,
          width: 50,
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor,
            shape: BoxShape.circle,
          ),
          child: Padding(
            child: FittedBox(child: Text('\$${tx.amount}')),
            padding: EdgeInsets.all(10),
          ),
        ),
        title: Text(
          '${tx.title}',
          style: Theme.of(context).textTheme.headline3,
        ),
        subtitle:
            Text(DateFormat.yMMMd().format(tx.datetime)),
        trailing: MediaQuery.of(context).size.width > 360
            ? ElevatedButton.icon(
        
                onPressed: () {
                  deleteTx(tx.id);},
                icon: Icon(Icons.delete),
                label: Text('delete me!'),
                )
            : IconButton(
                color: Theme.of(context).errorColor,
                icon: Icon(Icons.delete),
                onPressed: () {
                  deleteTx(tx.id);
                }),
      ),
    );
  }
}
