import 'package:flutter/material.dart';




import '../models/transaction.dart';
import './ListTransactionItem.dart';
class TransactionList extends StatelessWidget {
  final List<Transaction> tList;
  final Function deleteTx;

  TransactionList(this.tList, this.deleteTx);

  @override
  Widget build(BuildContext context) {
      // print('build called at transactionlist');
    return tList.isEmpty
        ? LayoutBuilder(
            builder: (context, constraints) {
              return Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  Container(
                    height: constraints.maxHeight * 0.1,
                    margin: EdgeInsets.only(top: 5),
                    alignment: Alignment.center,
                    child: Text(
                      'currently Empty !!',
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                  ),
                  Container(
                    height: constraints.maxHeight * 0.7,
                    child: Image.asset(
                      'assets/images/Method Draw Image.png',
                      fit: BoxFit.fill,
                    ),
                  ),
                ],
              );
            },
          )
        : ListView.builder(
            itemBuilder: (bcntx, index) {
              return ListTransactionItem(tx: tList[index], deleteTx: deleteTx);
            },
            itemCount: tList.length,
            scrollDirection: Axis.vertical,
          );
  }
}



 // return Card(
                //   elevation: 10,
                //   child: Row(
                //       // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                //       children: [
                //         Container(
                //             margin: EdgeInsets.symmetric(
                //                 vertical: 25, horizontal: 10),
                //             child: Text(
                //               '\$${tList[index].amount.toStringAsFixed(2)}',
                //               style: TextStyle(
                //                 fontWeight: FontWeight.bold,
                //                 fontSize: 15,
                //                 color: Theme.of(context).primaryColorDark,
                //               ),
                //               textAlign: TextAlign.center,
                //             ),
                //             padding: EdgeInsets.all(10),
                //             decoration: BoxDecoration(
                //                 border: Border.all(
                //               width: 1,
                //               color: Theme.of(context).primaryColorLight,
                //             ))),
                //         Column(
                //           crossAxisAlignment: CrossAxisAlignment.center,
                //           children: [
                //             Text(
                //               tList[index].title,
                //               // style: TextStyle(
                //               //   fontWeight: FontWeight.bold,
                //               //   fontSize: 16,
                //               //   color: Theme.of(context).accentColor,
                //               //   fontStyle: FontStyle.italic,
                //               // ),
                //               style: Theme.of(context).textTheme.headline3,
                //             ),
                //             Text(
                //               DateFormat.yMMMd('en_US')
                //                   .format(tList[index].datetime),
                //               style: TextStyle(color: Colors.grey),
                //             )
                //           ],
                //         ),
                //       ]),
                // );